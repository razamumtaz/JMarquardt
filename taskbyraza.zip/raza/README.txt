Task Details:


The task – categories tree: 

  

Background: a navigation tree that allows adding, editing & removing children endlessly. 

-         The user could add at any level a child 

-         If it has no parents – it should be at the root level. 

-         Each entry should contain 3 buttons –edit, delete, add a child. 

-         Each level will be collapsible. When clicking on its Title 